# Laporan Penjualan (contoh)

Program Python standar-library ini menghitung omzet, biaya total, dan laba dari data Kopi, Teh, dan Roti, lalu menghasilkan laporan HTML ringkas, CSV, serta arsip ZIP berisi keduanya.

## Hasil perhitungan

| Produk | Unit | Omzet | Biaya | Laba |
|---|---:|---:|---:|---:|
| Kopi | 10 | Rp200.000 | Rp120.000 | Rp80.000 |
| Teh | 8 | Rp120.000 | Rp56.000 | Rp64.000 |
| Roti | 5 | Rp90.000 | Rp50.000 | Rp40.000 |
| **Total** | **23** | **Rp410.000** | **Rp226.000** | **Rp184.000** |

## Menjalankan

Persyaratan: Python 3.10 atau lebih baru. Tidak memerlukan paket pihak ketiga maupun koneksi internet.

```sh
python3 main.py
```

Ketiga file akan dibuat di direktori `output/`:

- `laporan_penjualan.html` — laporan siap dibuka di browser.
- `laporan_penjualan.csv` — data berbentuk CSV (UTF-8 dengan BOM agar mudah dibuka di spreadsheet).
- `laporan_penjualan.zip` — arsip unduhan berisi HTML dan CSV.

Nilai mata uang CSV ditulis sebagai angka rupiah tanpa pemisah ribuan agar mudah diolah. Biaya total adalah biaya per unit dikali jumlah unit; laba = omzet dikurangi biaya total.
