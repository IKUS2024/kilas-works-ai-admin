#!/usr/bin/env python3
"""Generate a concise Indonesian sales report, CSV, and downloadable ZIP."""
from __future__ import annotations

import csv
import html
import os
from pathlib import Path
import zipfile

OUTPUT_DIR = Path(__file__).resolve().parent / "output"
PRODUCTS = [
    {"produk": "Kopi", "jumlah": 10, "harga_jual": 20_000, "biaya_unit": 12_000},
    {"produk": "Teh", "jumlah": 8, "harga_jual": 15_000, "biaya_unit": 7_000},
    {"produk": "Roti", "jumlah": 5, "harga_jual": 18_000, "biaya_unit": 10_000},
]


def rupiah(amount: int) -> str:
    return "Rp" + f"{amount:,}".replace(",", ".")


def calculate_rows() -> list[dict[str, int | str]]:
    rows = []
    for item in PRODUCTS:
        quantity = item["jumlah"]
        revenue = quantity * item["harga_jual"]
        cost = quantity * item["biaya_unit"]
        rows.append({**item, "omzet": revenue, "biaya": cost, "laba": revenue - cost})
    return rows


def write_csv(rows: list[dict[str, int | str]], path: Path) -> None:
    columns = ["Produk", "Jumlah unit", "Harga jual/unit (Rp)", "Biaya/unit (Rp)", "Omzet (Rp)", "Biaya total (Rp)", "Laba (Rp)"]
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(columns)
        for row in rows:
            writer.writerow([row["produk"], row["jumlah"], row["harga_jual"], row["biaya_unit"], row["omzet"], row["biaya"], row["laba"]])
        writer.writerow(["TOTAL", sum(int(r["jumlah"]) for r in rows), "", "", sum(int(r["omzet"]) for r in rows), sum(int(r["biaya"]) for r in rows), sum(int(r["laba"]) for r in rows)])


def write_html(rows: list[dict[str, int | str]], path: Path) -> None:
    total_revenue = sum(int(r["omzet"]) for r in rows)
    total_cost = sum(int(r["biaya"]) for r in rows)
    total_profit = sum(int(r["laba"]) for r in rows)
    body = "\n".join(
        "<tr>" + "".join((
            f'<td>{html.escape(str(r["produk"]))}</td>',
            f'<td class="num">{int(r["jumlah"])}</td>',
            f'<td class="num">{rupiah(int(r["harga_jual"]))}</td>',
            f'<td class="num">{rupiah(int(r["biaya_unit"]))}</td>',
            f'<td class="num">{rupiah(int(r["omzet"]))}</td>',
            f'<td class="num">{rupiah(int(r["biaya"]))}</td>',
            f'<td class="num profit">{rupiah(int(r["laba"]))}</td>',
        )) + "</tr>"
        for r in rows
    )
    document = f'''<!doctype html>
<html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Laporan Penjualan</title><style>
:root{{color-scheme:light;--ink:#18332b;--green:#146c50;--pale:#eff7f2;--line:#dce8e0}}
*{{box-sizing:border-box}}body{{margin:0;background:#f5f8f6;color:var(--ink);font:15px/1.5 system-ui,-apple-system,"Segoe UI",sans-serif}}
main{{max-width:1000px;margin:36px auto;padding:0 20px}}h1{{margin:0;font-size:1.8rem}}.sub{{margin:5px 0 22px;color:#587067}}
.cards{{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:20px}}.card{{background:white;border:1px solid var(--line);border-radius:12px;padding:16px}}.label{{font-size:.85rem;color:#587067}}.value{{font-size:1.35rem;font-weight:750;margin-top:4px}}.profit{{color:var(--green);font-weight:700}}
.table-wrap{{overflow-x:auto;background:white;border:1px solid var(--line);border-radius:12px}}table{{width:100%;border-collapse:collapse;min-width:760px}}th,td{{padding:12px 14px;border-bottom:1px solid var(--line);text-align:left}}th{{background:var(--pale);font-size:.84rem}}.num{{text-align:right;white-space:nowrap}}tfoot td{{font-weight:750;background:var(--pale)}}.note{{font-size:.85rem;color:#587067;margin-top:12px}}
@media(max-width:620px){{main{{margin:22px auto}}.cards{{grid-template-columns:1fr}}}}
</style></head><body><main><h1>Laporan Penjualan</h1><p class="sub">Ringkasan omzet, biaya, dan laba berdasarkan data contoh.</p>
<section class="cards" aria-label="Ringkasan total"><div class="card"><div class="label">Total omzet</div><div class="value">{rupiah(total_revenue)}</div></div><div class="card"><div class="label">Total biaya</div><div class="value">{rupiah(total_cost)}</div></div><div class="card"><div class="label">Total laba</div><div class="value profit">{rupiah(total_profit)}</div></div></section>
<div class="table-wrap"><table><thead><tr><th>Produk</th><th class="num">Unit</th><th class="num">Harga jual/unit</th><th class="num">Biaya/unit</th><th class="num">Omzet</th><th class="num">Biaya total</th><th class="num">Laba</th></tr></thead><tbody>{body}</tbody><tfoot><tr><td>TOTAL</td><td class="num">{sum(int(r["jumlah"]) for r in rows)}</td><td></td><td></td><td class="num">{rupiah(total_revenue)}</td><td class="num">{rupiah(total_cost)}</td><td class="num profit">{rupiah(total_profit)}</td></tr></tfoot></table></div>
<p class="note">Laba dihitung sebagai omzet dikurangi biaya total; omzet dan biaya per produk dihitung dari jumlah unit.</p></main></body></html>'''
    path.write_text(document, encoding="utf-8")


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    rows = calculate_rows()
    csv_path = OUTPUT_DIR / "laporan_penjualan.csv"
    html_path = OUTPUT_DIR / "laporan_penjualan.html"
    zip_path = OUTPUT_DIR / "laporan_penjualan.zip"
    write_csv(rows, csv_path)
    write_html(rows, html_path)
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        archive.write(html_path, arcname="laporan_penjualan.html")
        archive.write(csv_path, arcname="laporan_penjualan.csv")
    for path in (html_path, csv_path, zip_path):
        if path.stat().st_size > 65_536:
            raise RuntimeError(f"Ukuran keluaran melebihi batas: {path.name}")
    print(f"Laporan dibuat di {OUTPUT_DIR}: HTML, CSV, dan ZIP")


if __name__ == "__main__":
    main()
